// Example Valid URLs: https://learning.ccbp.in/, https://www.google.com/
let bookmarkFormEl = document.getElementById("bookmarkForm");
let siteNameInputEl = document.getElementById("siteNameInput");
let siteNameErrMsgEl = document.getElementById("siteNameErrMsg");
let siteUrlInputEl = document.getElementById("siteUrlInput");
let siteUrlErrMsgEl = document.getElementById("siteUrlErrMsg")
let bookmarksListEl = document.getElementById("bookmarksList")


let creds = {
    title: "",
    url: ""
}



siteNameInputEl.addEventListener("blur", function(event) {
    if (event.target.value === "") {
        siteNameErrMsgEl.textContent = "Required*"
        siteNameErrMsgEl.style.color = "red"
    } else {
        siteNameErrMsgEl.textContent = ""
    }
    creds.title = event.target.value
})
siteUrlInputEl.addEventListener("blur", function(event) {
    if (event.target.value === "") {
        siteUrlErrMsgEl.textContent = "Required*"
        siteUrlErrMsgEl.style.color = "red"
    } else {
        siteUrlErrMsgEl.textContent = ""
    }
    creds.url = event.target.value
})

function submitDetails(creds) {
    let bookmarkEl = document.createElement("li")
    bookmarksListEl.appendChild(bookmarkEl)

    let titleEl = document.createElement("p")
    titleEl.textContent = creds.title;
    titleEl.style.color = "darkblue"
    bookmarkEl.appendChild(titleEl)



    let urlEl = document.createElement("a")
    urlEl.href = creds.url
    urlEl.target = "_blank"
    urlEl.textContent = creds.url;
    bookmarkEl.appendChild(urlEl)

    siteNameInputEl.value = ""
    siteUrlInputEl.value = ""
}


bookmarkFormEl.addEventListener("submit", function(event) {
    event.preventDefault()
    submitDetails(creds)

})